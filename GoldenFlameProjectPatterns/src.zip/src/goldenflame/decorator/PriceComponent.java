package goldenflame.decorator;

public interface PriceComponent {
    float getTotal();
}
