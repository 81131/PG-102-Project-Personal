package goldenflame.strategy;

public interface PaymentStrategy {
    void pay(float amount);
}
