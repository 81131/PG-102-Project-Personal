package goldenflame.observer;

public interface EventListener {
    void onEvent(Event event);
}
