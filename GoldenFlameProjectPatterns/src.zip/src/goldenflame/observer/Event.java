package goldenflame.observer;

public interface Event {
}
